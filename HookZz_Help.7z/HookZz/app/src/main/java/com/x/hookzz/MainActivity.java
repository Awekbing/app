package com.x.hookzz;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.xposedhook.dexdump.Dumpper;

public class MainActivity extends AppCompatActivity {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Example of a call to a native method
        TextView tv = (TextView) findViewById(R.id.sample_text);
        tv.setText(stringFromJNI());
        Dumpper.dump();
        /**********************
         *
         * 在JNI下面有个target.dex文件  ，对应的是工程的dex  module转换来的, 还有对应的手机上的libart.so文件
         *
         * 需要push这dex到/data/local/tmp/下面
         *
         * 操作：Hook  libart.so 中的defineClass  然后去调用DexClassLoader  ，应该会执行Hook后的函数，但是没有执行
         *
         * 希望大佬指点一下
         *
         *
         * *******************************/
        new LoadDex().cloadDex(this, getClassLoader());
    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();
}
