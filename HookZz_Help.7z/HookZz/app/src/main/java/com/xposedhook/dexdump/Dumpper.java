package com.xposedhook.dexdump;

 
public class Dumpper {

	// native层实现的dump函数
    public static native void dump();
}
