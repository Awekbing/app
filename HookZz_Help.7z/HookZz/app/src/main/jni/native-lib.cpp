#include <jni.h>
#include <android/log.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <linux/in.h>
#include <netdb.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <string>
#include "ElfTool.h"

#include "hookzz.h"
#define TEST_printf 1
#define TEST_send 1
#define TEST_sendto 1
#define TEST_connect 1
#define TEST_freeaddrinfo 1
#define TEST_getaddrinfo 1
#define TEST_case_001 0

typedef unsigned char byte;

void * (*old_art_hook)(void* self, const char* descriptor, size_t hash,
                       int class_loader,
                       int dex_file,
                       int dex_class_def) = NULL;

void * new_art_hook(void* self, const char* descriptor, size_t hash,
                    int class_loader,
                    int dex_file,
                    int dex_class_def) {
    LOGD("art hook run ------:");
    return old_art_hook( self, descriptor, hash, class_loader, dex_file, dex_class_def);
}

extern "C"
JNIEXPORT jstring

JNICALL
Java_com_x_hookzz_MainActivity_stringFromJNI(
        JNIEnv *env,
        jobject /* this */) {
    std::string hello = "com_x_hookzz Hello from C++";
    return env->NewStringUTF(hello.c_str());
}

extern "C"
JNIEXPORT void JNICALL
Java_com_xposedhook_dexdump_Dumpper_dump(JNIEnv *env, jclass type) {
     const char *hook_sym = "_ZN3art11ClassLinker11DefineClassEPNS_6ThreadEPKcjNS_6HandleINS_6mirror11ClassLoaderEEERKNS_7DexFileERKNS9_8ClassDefE";
    int sym_addr = ElfTool::findSymbolByName("/system/lib/libart.so", hook_sym);
    ZzHookReplace((void *) sym_addr, (void *) new_art_hook, (void **) &old_art_hook);
    __android_log_print(ANDROID_LOG_ERROR, TAG, "addr: %08x             Java_com_xposedhook_dexdump_Dumpper_dump called", sym_addr);
}