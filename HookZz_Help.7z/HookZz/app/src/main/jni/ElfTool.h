#include <dlfcn.h>
#include <android/log.h>

#ifndef ELFTOOL_H
#define ELFTOOL_H
#include <stdio.h>
#include <string.h>
#include <cstdlib>
#include <fcntl.h>
#include <string>
#include <elf.h>
// log标签
#define  TAG    "DEX_HOOK"
// 定义info信息
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,TAG,__VA_ARGS__)
// 定义debug信息
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, TAG, __VA_ARGS__)
// 定义error信息
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,TAG,__VA_ARGS__)
namespace ElfTool {
    int get_module_address(const char *soname);
    int findSymbolByName(const char *soname, const char *symbol);
    uint32_t find_got_entry_address(const char *module_path, const char *symbol_name);
};

#endif //DUMPSHELL_CYDIAHOOK_H
