package com.x.dex;

import android.app.Activity;
import android.widget.Toast;

/**
 * 生成dex
 *      dx --dex --output=target.dex classes.jar
 *      adb push target.dex /data/local/tmp/target.dex
 */

public class DexFucntion {

    public void foo1() {
        Logger.d("foo1 function");
    }

    public void showToast(Activity activity) {
        Toast.makeText(activity, "showToast function call", Toast.LENGTH_SHORT).show();
    }
}
